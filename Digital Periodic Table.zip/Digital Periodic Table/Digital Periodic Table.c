#include<stdio.h>
#include<string.h>
#include<stdlib.h>

void data();

int main()
{
    system("COLOR FC");
    char s[20];
    int n, choice;

    printf("                                       Course Name: Software Development Project - I \n");
    printf("                                                   Course Code: CSE-1200 \n");
    printf("                                    Project Name: Digital Periodic Table of the Element \n");
    printf("                                         Section: B || Level-1 Term-II || Group: B \n");
    printf("        ---------------------------------------------------------------------------------------------------------- \n");
    printf("                                                :: Digital Periodic Table :: \n");
    printf("        ---------------------------------------------------------------------------------------------------------- \n");
    printf("                |  H |                                                                               | He |  \n");
    printf("                | Li | Be |                                                 |  B |  C |  N |  O |  F | Ne |  \n");
    printf("                | Na | Mg |                                                 | Al | Si |  P |  S | Cl | Ar |  \n");
    printf("                |  K | Ca | Sc | Ti |  V | Cr | Mn | Fe | Co | Ni | Cu | Zn | Ga | Ge | As | Se | Br | Kr |  \n");
    printf("                | Rb | Sr |  Y | Zr | Nb | Mo | Tc | Ru | Rh | Pd | Ag | Cd | In | Sn | Sb | Te |  I | Xe |  \n");
    printf("                | Cs | Ba | LS | Hf | Ta |  W | Re | Os | Ir | Pt | Au | Hg | Tl | Pb | Bi | Po | At | Rn |  \n");
    printf("                | Fr | Ra | AS | Rf | Db | Sg | Bh | Hs | Mt | Ds | Rg | Cn | Nh | Fl | Mc | Lv | Ts | Og |  \n\n");
    printf("           Lanthanide Series (LS) : | La | Ce | Pr | Nd | Pm | Sm | Eu | Gd | Tb | Dy | Ho | Er | Tm | Yb | Lu |  \n");
    printf("           Actinide Series   (AS) : | Ac | Th | Pa |  U | Np | Pu | Am | Cm | Bk | Cf | Es | Fm | Md | No | Lr |  \n");
    printf("       ----------------------------------------------------------------------------------------------------------- \n");

    loop1:
    printf("\t# Which Search Do You Want? \n\n");
    printf("\t1. Search by Atomic Number  \n");
    printf("\t2. Search by Symbol  \n");
    printf("\t3. Search by Element Name  \n\n");

    printf("\tEnter Your Choice: ");
    scanf("%d", &choice);

    switch(choice)
    {
        case 1:
            printf("\n\tEnter an Atomic Number: ");
            scanf("%d", &n);
            printf("\n\n");
            system("COLOR 0E");
            if(n==1)
            {
                data1();
            }
            else if(n==2)
            {
                data2();
            }
            else if(n==3)
            {
                data3();
            }
            else if(n==4)
            {
                data4();
            }
            else if(n==5)
            {
                data5();
            }
            else if(n==6)
            {
                data6();
            }
            else if(n==7)
            {
                data7();
            }
            else if(n==8)
            {
                data8();
            }
            else if(n==9)
            {
                data9();
            }
            else if(n==10)
            {
                data10();
            }
            else if(n==11)
            {
                data11();
            }
            else if(n==12)
            {
                data12();
            }
            else if(n==13)
            {
                data13();
            }
            else if(n==14)
            {
                data14();
            }
            else if(n==15)
            {
                data15();
            }
            else if(n==16)
            {
                data16();
            }
            else if(n==17)
            {
                data17();
            }
            else if(n==18)
            {
                data18();
            }
            else if(n==19)
            {
                data19();
            }
            else if(n==20)
            {
                data20();
            }
            else if(n==21)
            {
                data21();
            }
            else if(n==22)
            {
                data22();
            }
            else if(n==23)
            {
                data23();
            }
            else if(n==24)
            {
                data24();
            }
            else if(n==25)
            {
                data25();
            }
            else if(n==26)
            {
                data26();
            }
            else if(n==27)
            {
                data27();
            }
            else if(n==28)
            {
                data28();
            }
            else if(n==29)
            {
                data29();
            }
            else if(n==30)
            {
                data30();
            }
            else if(n==31)
            {
                data31();
            }
            else if(n==32)
            {
                data32();
            }
            else if(n==33)
            {
                data33();
            }
            else if(n==34)
            {
                data34();
            }
            else if(n==35)
            {
                data35();
            }
            else if(n==36)
            {
                data36();
            }
            else if(n==37)
            {
                data37();
            }
            else if(n==38)
            {
                data38();
            }
            else if(n==39)
            {
                data39();
            }
            else if(n==40)
            {
                data40();
            }
            else if(n==41)
            {
                data41();
            }
            else if(n==42)
            {
                data42();
            }
            else if(n==43)
            {
                data43();
            }
            else if(n==44)
            {
                data44();
            }
            else if(n==45)
            {
                data45();
            }
            else if(n==46)
            {
                data46();
            }
            else if(n==47)
            {
                data47();
            }
            else if(n==48)
            {
                data48();
            }
            else if(n==49)
            {
                data49();
            }
            else if(n==50)
            {
                data50();
            }
            else if(n==51)
            {
                data51();
            }
            else if(n==52)
            {
                data52();
            }
            else if(n==53)
            {
                data53();
            }
            else if(n==54)
            {
                data54();
            }
            else if(n==55)
            {
                data55();
            }
            else if(n==56)
            {
                data56();
            }
            else if(n==57)
            {
                data57();
            }
            else if(n==58)
            {
                data58();
            }
            else if(n==59)
            {
                data59();
            }
            else if(n==60)
            {
                data60();
            }
            else if(n==61)
            {
                data61();
            }
            else if(n==62)
            {
                data62();
            }
            else if(n==63)
            {
                data63();
            }
            else if(n==64)
            {
                data64();
            }
            else if(n==65)
            {
                data65();
            }
            else if(n==66)
            {
                data66();
            }
            else if(n==67)
            {
                data67();
            }
            else if(n==68)
            {
                data68();
            }
            else if(n==69)
            {
                data69();
            }
            else if(n==70)
            {
                data70();
            }
            else if(n==71)
            {
                data71();
            }
            else if(n==72)
            {
                data72();
            }
            else if(n==73)
            {
                data73();
            }
            else if(n==74)
            {
                data74();
            }
            else if(n==75)
            {
                data75();
            }
            else if(n==76)
            {
                data76();
            }
            else if(n==77)
            {
                data77();
            }
            else if(n==78)
            {
                data78();
            }
            else if(n==79)
            {
                data79();
            }
            else if(n==80)
            {
                data80();
            }
            else if(n==81)
            {
                data81();
            }
            else if(n==82)
            {
                data82();
            }
            else if(n==83)
            {
                data83();
            }
            else if(n==84)
            {
                data84();
            }
            else if(n==85)
            {
                data85();
            }
            else if(n==86)
            {
                data86();
            }
            else if(n==87)
            {
                data87();
            }
            else if(n==88)
            {
                data88();
            }
            else if(n==89)
            {
                data89();
            }
            else if(n==90)
            {
                data90();
            }
            else if(n==91)
            {
                data91();
            }
            else if(n==92)
            {
                data92();
            }
            else if(n==93)
            {
                data93();
            }
            else if(n==94)
            {
                data94();
            }
            else if(n==95)
            {
                data95();
            }
            else if(n==96)
            {
                data96();
            }
            else if(n==97)
            {
                data97();
            }
            else if(n==98)
            {
                data98();
            }
            else if(n==99)
            {
                data99();
            }
            else if(n==100)
            {
                data100();
            }
            else if(n==101)
            {
                data101();
            }
            else if(n==102)
            {
                data102();
            }
            else if(n==103)
            {
                data103();
            }
            else if(n==104)
            {
                data104();
            }
            else if(n==105)
            {
                data105();
            }
            else if(n==106)
            {
                data106();
            }
            else if(n==107)
            {
                data107();
            }
            else if(n==108)
            {
                data108();
            }
            else if(n==109)
            {
                data109();
            }
            else if(n==110)
            {
                data110();
            }
            else if(n==111)
            {
                data111();
            }
            else if(n==112)
            {
                data112();
            }
            else if(n==113)
            {
                data113();
            }
            else if(n==114)
            {
                data114();
            }
            else if(n==115)
            {
                data115();
            }
            else if(n==116)
            {
                data116();
            }
            else if(n==117)
            {
                data117();
            }
            else if(n==118)
            {
                data118();
            }
            else
            {
                printf("\tThere is No Element Exists for Atomic Number '%d'. Search Again.... \n\n", n);
            }

            break;

        case 2:
            printf("\n\tEnter a Symbol: ");
            scanf("%s", s);
            printf("\n");
            system("COLOR 0E");

            if(strcmp(s,"H")==0)
            {
                data1();
            }
            else if(strcmp(s,"He")==0)
            {
                data2();
            }
            else if(strcmp(s,"Li")==0)
            {
                data3();
            }
            else if(strcmp(s,"Be")==0)
            {
                data4();
            }
            else if(strcmp(s,"B")==0)
            {
                data5();
            }
            else if(strcmp(s,"C")==0)
            {
                data6();
            }
            else if(strcmp(s,"N")==0)
            {
                data7();
            }
            else if(strcmp(s,"O")==0)
            {
                data8();
            }
            else if(strcmp(s,"F")==0)
            {
                data9();
            }
            else if(strcmp(s,"Ne")==0)
            {
                data10();
            }
            else if(strcmp(s,"Na")==0)
            {
                data11();
            }
            else if(strcmp(s,"Mg")==0)
            {
                data12();
            }
            else if(strcmp(s,"Al")==0)
            {
                data13();
            }
            else if(strcmp(s,"Si")==0)
            {
                data14();
            }
            else if(strcmp(s,"P")==0)
            {
                data15();
            }
            else if(strcmp(s,"S")==0)
            {
                data16();
            }
            else if(strcmp(s,"Cl")==0)
            {
                data17();
            }
            else if(strcmp(s,"Ar")==0)
            {
                data18();
            }
            else if(strcmp(s,"K")==0)
            {
                data19();
            }
            else if(strcmp(s,"Ca")==0)
            {
                data20();
            }
            else if(strcmp(s,"Sc")==0)
            {
                data21();
            }
            else if(strcmp(s,"Ti")==0)
            {
                data22();
            }
            else if(strcmp(s,"V")==0)
            {
                data23();
            }
            else if(strcmp(s,"Cr")==0)
            {
                data24();
            }
            else if(strcmp(s,"Mn")==0)
            {
                data25();
            }
            else if(strcmp(s,"Fe")==0)
            {
                data26();
            }
            else if(strcmp(s,"Co")==0)
            {
                data27();
            }
            else if(strcmp(s,"Ni")==0)
            {
                data28();
            }
            else if(strcmp(s,"Cu")==0)
            {
                data29();
            }
            else if(strcmp(s,"Zn")==0)
            {
                data30();
            }
            else if(strcmp(s,"Ga")==0)
            {
                data31();
            }
            else if(strcmp(s,"Ge")==0)
            {
                data32();
            }
            else if(strcmp(s,"As")==0)
            {
                data33();
            }
            else if(strcmp(s,"Se")==0)
            {
                data34();
            }
            else if(strcmp(s,"Br")==0)
            {
                data35();
            }
            else if(strcmp(s,"Kr")==0)
            {
                data36();
            }
            else if(strcmp(s,"Rb")==0)
            {
                data37();
            }
            else if(strcmp(s,"Sr")==0)
            {
                data38();
            }
            else if(strcmp(s,"Y")==0)
            {
                data39();
            }
            else if(strcmp(s,"Zr")==0)
            {
                data40();
            }
            else if(strcmp(s,"Nb")==0)
            {
                data41();
            }
            else if(strcmp(s,"Mo")==0)
            {
                data42();
            }
            else if(strcmp(s,"Tc")==0)
            {
                data43();
            }
            else if(strcmp(s,"Ru")==0)
            {
                data44();
            }
            else if(strcmp(s,"Rh")==0)
            {
                data45();
            }
            else if(strcmp(s,"Pd")==0)
            {
                data46();
            }
            else if(strcmp(s,"Ag")==0)
            {
                data47();
            }
            else if(strcmp(s,"Cd")==0)
            {
                data48();
            }
            else if(strcmp(s,"In")==0)
            {
                data49();
            }
            else if(strcmp(s,"Sn")==0)
            {
                data50();
            }
            else if(strcmp(s,"Sb")==0)
            {
                data51();
            }
            else if(strcmp(s,"Te")==0)
            {
                data52();
            }
            else if(strcmp(s,"I")==0)
            {
                data53();
            }
            else if(strcmp(s,"Xe")==0)
            {
                data54();
            }
            else if(strcmp(s,"Cs")==0)
            {
                data55();
            }
            else if(strcmp(s,"Ba")==0)
            {
                data56();
            }
            else if(strcmp(s,"La")==0)
            {
                data57();
            }
            else if(strcmp(s,"Ce")==0)
            {
                data58();
            }
            else if(strcmp(s,"Pr")==0)
            {
                data59();
            }
            else if(strcmp(s,"Nd")==0)
            {
                data60();
            }
            else if(strcmp(s,"Pm")==0)
            {
                data61();
            }
            else if(strcmp(s,"Sm")==0)
            {
                data62();
            }
            else if(strcmp(s,"Eu")==0)
            {
                data63();
            }
            else if(strcmp(s,"Gd")==0)
            {
                data64();
            }
            else if(strcmp(s,"Tb")==0)
            {
                data65();
            }
            else if(strcmp(s,"Dy")==0)
            {
                data66();
            }
            else if(strcmp(s,"Ho")==0)
            {
                data67();
            }
            else if(strcmp(s,"Er")==0)
            {
                data68();
            }
            else if(strcmp(s,"Tm")==0)
            {
                data69();
            }
            else if(strcmp(s,"Yb")==0)
            {
                data70();
            }
            else if(strcmp(s,"Lu")==0)
            {
                data71();
            }
            else if(strcmp(s,"Hf")==0)
            {
                data72();
            }
            else if(strcmp(s,"Ta")==0)
            {
                data73();
            }
            else if(strcmp(s,"W")==0)
            {
                data74();
            }
            else if(strcmp(s,"Re")==0)
            {
                data75();
            }
            else if(strcmp(s,"Os")==0)
            {
                data76();
            }
            else if(strcmp(s,"Ir")==0)
            {
                data77();
            }
            else if(strcmp(s,"Pt")==0)
            {
                data78();
            }
            else if(strcmp(s,"Au")==0)
            {
                data79();
            }
            else if(strcmp(s,"Hg")==0)
            {
                data80();
            }
            else if(strcmp(s,"Tl")==0)
            {
                data81();
            }
            else if(strcmp(s,"Pb")==0)
            {
                data82();
            }
            else if(strcmp(s,"Bi")==0)
            {
                data83();
            }
            else if(strcmp(s,"Po")==0)
            {
                data84();
            }
            else if(strcmp(s,"At")==0)
            {
                data85();
            }
            else if(strcmp(s,"Rn")==0)
            {
                data86();
            }
            else if(strcmp(s,"Fr")==0)
            {
                data87();
            }
            else if(strcmp(s,"Ra")==0)
            {
                data88();
            }
            else if(strcmp(s,"Ac")==0)
            {
                data89();
            }
            else if(strcmp(s,"Th")==0)
            {
                data90();
            }
            else if(strcmp(s,"Pa")==0)
            {
                data91();
            }
            else if(strcmp(s,"U")==0)
            {
                data92();
            }
            else if(strcmp(s,"Np")==0)
            {
                data93();
            }
            else if(strcmp(s,"Pu")==0)
            {
                data94();
            }
            else if(strcmp(s,"Am")==0)
            {
                data95();
            }
            else if(strcmp(s,"Cm")==0)
            {
                data96();
            }
            else if(strcmp(s,"Bk")==0)
            {
                data97();
            }
            else if(strcmp(s,"Cf")==0)
            {
                data98();
            }
            else if(strcmp(s,"Es")==0)
            {
                data99();
            }
            else if(strcmp(s,"Fm")==0)
            {
                data100();
            }
            else if(strcmp(s,"Md")==0)
            {
                data101();
            }
            else if(strcmp(s,"No")==0)
            {
                data102();
            }
            else if(strcmp(s,"Lr")==0)
            {
                data103();
            }
            else if(strcmp(s,"Rf")==0)
            {
                data104();
            }
            else if(strcmp(s,"Db")==0)
            {
                data105();
            }
            else if(strcmp(s,"Sg")==0)
            {
                data106();
            }
            else if(strcmp(s,"Bh")==0)
            {
                data107();
            }
            else if(strcmp(s,"Hs")==0)
            {
                data108();
            }
            else if(strcmp(s,"Mt")==0)
            {
                data109();
            }
            else if(strcmp(s,"Ds")==0)
            {
                data110();
            }
            else if(strcmp(s,"Rg")==0)
            {
                data111();
            }
            else if(strcmp(s,"Cn")==0)
            {
                data112();
            }
            else if(strcmp(s,"Nh")==0)
            {
                data113();
            }
            else if(strcmp(s,"Fl")==0)
            {
                data114();
            }
            else if(strcmp(s,"Mc")==0)
            {
                data115();
            }
            else if(strcmp(s,"Lv")==0)
            {
                data116();
            }
            else if(strcmp(s,"Ts")==0)
            {
                data117();
            }
            else if(strcmp(s,"Og")==0)
            {
                data118();
            }
            else
            {
                printf("\t:: ERROR! :: \n\tIncorrect Keyword \n\tThere is No Element Exists for Symbol '%s'.\n\n", s);
            }

            break;

        case 3:
            printf("\n\tEnter an Element Name: ");
            scanf("%s", s);
            printf("\n");
            system("COLOR 0E");

            if((strcmp(strupr(s),"HYDROGEN")==0) || (strcmp(strlwr(s),"hydrogen")==0))
            {
                data1();
            }
            else if((strcmp(strupr(s),"HELIUM")==0) || (strcmp(strlwr(s),"helium")==0))
            {
                data2();
            }
            else if((strcmp(strupr(s),"LITHIUM")==0) || (strcmp(strlwr(s),"lithium")==0))
            {
                data3();
            }
            else if((strcmp(strupr(s),"BERYLLIUM")==0) || (strcmp(strlwr(s),"beryllium")==0))
            {
                data4();
            }
            else if((strcmp(strupr(s),"BORON")==0) || (strcmp(strlwr(s),"boron")==0))
            {
                data5();
            }
            else if((strcmp(strupr(s),"CARBON")==0) || (strcmp(strlwr(s),"carbon")==0))
            {
                data6();
            }
            else if((strcmp(strupr(s),"NITROGEN")==0) || (strcmp(strlwr(s),"nitrogen")==0))
            {
                data7();
            }
            else if((strcmp(strupr(s),"OXYGEN")==0) || (strcmp(strlwr(s),"oxygen")==0))
            {
                data8();
            }
            else if((strcmp(strupr(s),"FLUORINE")==0) || (strcmp(strlwr(s),"fluorine")==0))
            {
                data9();
            }
            else if((strcmp(strupr(s),"NEON")==0) || (strcmp(strlwr(s),"neon")==0))
            {
                data10();
            }
            else if((strcmp(strupr(s),"SODIUM")==0) || (strcmp(strlwr(s),"sodium")==0))
            {
                data11();
            }
            else if((strcmp(strupr(s),"MAGNESIUM")==0) || (strcmp(strlwr(s),"magnesium")==0))
            {
                data12();
            }
            else if((strcmp(strupr(s),"ALUMINIUM")==0) || (strcmp(strlwr(s),"aluminium")==0))
            {
                data13();
            }
            else if((strcmp(strupr(s),"SILICON")==0) || (strcmp(strlwr(s),"silicon")==0))
            {
                data14();
            }
            else if((strcmp(strupr(s),"PHOSPHORUS")==0) || (strcmp(strlwr(s),"phosphorus")==0))
            {
                data15();
            }
            else if((strcmp(strupr(s),"SULPHUR")==0) || (strcmp(strlwr(s),"sulphur")==0))
            {
                data16();
            }
            else if((strcmp(strupr(s),"CHLORINE")==0) || (strcmp(strlwr(s),"chlorine")==0))
            {
                data17();
            }
            else if((strcmp(strupr(s),"ARGON")==0) || (strcmp(strlwr(s),"argon")==0))
            {
                data18();
            }
            else if((strcmp(strupr(s),"POTASSIUM")==0) || (strcmp(strlwr(s),"potassium")==0))
            {
                data19();
            }
            else if((strcmp(strupr(s),"CALCIUM")==0) || (strcmp(strlwr(s),"calcium")==0))
            {
                data20();
            }
            else if((strcmp(strupr(s),"SCANDIUM")==0) || (strcmp(strlwr(s),"scandium")==0))
            {
                data21();
            }
            else if((strcmp(strupr(s),"TITANIUM")==0) || (strcmp(strlwr(s),"titanium")==0))
            {
                data22();
            }
            else if((strcmp(strupr(s),"VANADIUM")==0) || (strcmp(strlwr(s),"vanadium")==0))
            {
                data23();
            }
            else if((strcmp(strupr(s),"CHROMIUM")==0) || (strcmp(strlwr(s),"chromium")==0))
            {
                data24();
            }
            else if((strcmp(strupr(s),"MANGANESE")==0) || (strcmp(strlwr(s),"manganese")==0))
            {
                data25();
            }
            else if((strcmp(strupr(s),"IRON")==0) || (strcmp(strlwr(s),"iron")==0))
            {
                data26();
            }
            else if((strcmp(strupr(s),"COBALT")==0) || (strcmp(strlwr(s),"cobalt")==0))
            {
                data27();
            }
            else if((strcmp(strupr(s),"NICKEL")==0) || (strcmp(strlwr(s),"nickel")==0))
            {
                data28();
            }
            else if((strcmp(strupr(s),"COPPER")==0) || (strcmp(strlwr(s),"copper")==0))
            {
                data29();
            }
            else if((strcmp(strupr(s),"ZINC")==0) || (strcmp(strlwr(s),"zinc")==0))
            {
                data30();
            }
            else if((strcmp(strupr(s),"GALLIUM")==0) || (strcmp(strlwr(s),"gallium")==0))
            {
                data31();
            }
            else if((strcmp(strupr(s),"GERMANIUM")==0) || (strcmp(strlwr(s),"germanium")==0))
            {
                data32();
            }
            else if((strcmp(strupr(s),"ARSENIC")==0) || (strcmp(strlwr(s),"arsenic")==0))
            {
                data33();
            }
            else if((strcmp(strupr(s),"SELENIUM")==0) || (strcmp(strlwr(s),"selenium")==0))
            {
                data34();
            }
            else if((strcmp(strupr(s),"BROMINE")==0) || (strcmp(strlwr(s),"bromine")==0))
            {
                data35();
            }
            else if((strcmp(strupr(s),"KRYPTON")==0) || (strcmp(strlwr(s),"krypton")==0))
            {
                data36();
            }
            else if((strcmp(strupr(s),"RUBIDIUM")==0) || (strcmp(strlwr(s),"rubidium")==0))
            {
                data37();
            }
            else if((strcmp(strupr(s),"STRONTIUM")==0) || (strcmp(strlwr(s),"strontium")==0))
            {
                data38();
            }
            else if((strcmp(strupr(s),"YTTRIUM")==0) || (strcmp(strlwr(s),"yttrium")==0))
            {
                data39();
            }
            else if((strcmp(strupr(s),"ZIRCONIUM")==0) || (strcmp(strlwr(s),"zirconium")==0))
            {
                data40();
            }
            else if((strcmp(strupr(s),"NIOBIUM")==0) || (strcmp(strlwr(s),"niobium")==0))
            {
                data41();
            }
            else if((strcmp(strupr(s),"MOLYBDENUM")==0) || (strcmp(strlwr(s),"molybdenum")==0))
            {
                data42();
            }
            else if((strcmp(strupr(s),"TECHNETIUM")==0) || (strcmp(strlwr(s),"technetium")==0))
            {
                data43();
            }
            else if((strcmp(strupr(s),"RUTHENIUM")==0) || (strcmp(strlwr(s),"ruthenium")==0))
            {
                data44();
            }
            else if((strcmp(strupr(s),"RHODIUM")==0) || (strcmp(strlwr(s),"rhodium")==0))
            {
                data45();
            }
            else if((strcmp(strupr(s),"PALLADIUM")==0) || (strcmp(strlwr(s),"palladium")==0))
            {
                data46();
            }
            else if((strcmp(strupr(s),"SILVER")==0) || (strcmp(strlwr(s),"silver")==0))
            {
                data47();
            }
            else if((strcmp(strupr(s),"CADMIUM")==0) || (strcmp(strlwr(s),"cadmium")==0))
            {
                data48();
            }
            else if((strcmp(strupr(s),"INDIUM")==0) || (strcmp(strlwr(s),"indium")==0))
            {
                data49();
            }
            else if((strcmp(strupr(s),"TIN")==0) || (strcmp(strlwr(s),"tin")==0))
            {
                data50();
            }
            else if((strcmp(strupr(s),"ANTIMONY")==0) || (strcmp(strlwr(s),"antimony")==0))
            {
                data51();
            }
            else if((strcmp(strupr(s),"TELLURIUM")==0) || (strcmp(strlwr(s),"tellurium")==0))
            {
                data52();
            }
            else if((strcmp(strupr(s),"IODINE")==0) || (strcmp(strlwr(s),"iodine")==0))
            {
                data53();
            }
            else if((strcmp(strupr(s),"XENON")==0) || (strcmp(strlwr(s),"xenon")==0))
            {
                data54();
            }
            else if((strcmp(strupr(s),"CAESIUM")==0) || (strcmp(strlwr(s),"caesium")==0))
            {
                data55();
            }
            else if((strcmp(strupr(s),"BARIUM")==0) || (strcmp(strlwr(s),"barium")==0))
            {
                data56();
            }
            else if((strcmp(strupr(s),"LANTHANUM")==0) || (strcmp(strlwr(s),"lanthanum")==0))
            {
                data57();
            }
            else if((strcmp(strupr(s),"CERIUM")==0) || (strcmp(strlwr(s),"cerium")==0))
            {
                data58();
            }
            else if((strcmp(strupr(s),"PRASEODYMIUM")==0) || (strcmp(strlwr(s),"praseodymium")==0))
            {
                data59();
            }
            else if((strcmp(strupr(s),"NEODYMIUM")==0) || (strcmp(strlwr(s),"neodymium")==0))
            {
                data60();
            }
            else if((strcmp(strupr(s),"PROMETHIUM")==0) || (strcmp(strlwr(s),"promethium")==0))
            {
                data61();
            }
            else if((strcmp(strupr(s),"SAMARIUM")==0) || (strcmp(strlwr(s),"samarium")==0))
            {
                data62();
            }
            else if((strcmp(strupr(s),"EUROPIUM")==0) || (strcmp(strlwr(s),"europium")==0))
            {
                data63();
            }
            else if((strcmp(strupr(s),"GADOLINIUM")==0) || (strcmp(strlwr(s),"gadolinium")==0))
            {
                data64();
            }
            else if((strcmp(strupr(s),"TERBIUM")==0) || (strcmp(strlwr(s),"terbium")==0))
            {
                data65();
            }
            else if((strcmp(strupr(s),"DYSPROSIUM")==0) || (strcmp(strlwr(s),"dysprosium")==0))
            {
                data66();
            }
            else if((strcmp(strupr(s),"HOLMIUM")==0) || (strcmp(strlwr(s),"holmium")==0))
            {
                data67();
            }
            else if((strcmp(strupr(s),"ERBIUM")==0) || (strcmp(strlwr(s),"erbium")==0))
            {
                data68();
            }
            else if((strcmp(strupr(s),"THULIUM")==0) || (strcmp(strlwr(s),"thulium")==0))
            {
                data69();
            }
            else if((strcmp(strupr(s),"YTTERBIUM")==0) || (strcmp(strlwr(s),"ytterbium")==0))
            {
                data70();
            }
            else if((strcmp(strupr(s),"LUTETIUM")==0) || (strcmp(strlwr(s),"lutetium")==0))
            {
                data71();
            }
            else if((strcmp(strupr(s),"HAFNIUM")==0) || (strcmp(strlwr(s),"hafnium")==0))
            {
                data72();
            }
            else if((strcmp(strupr(s),"TANTALUM")==0) || (strcmp(strlwr(s),"tantalum")==0))
            {
                data73();
            }
            else if((strcmp(strupr(s),"TUNGSTEN")==0) || (strcmp(strlwr(s),"tungsten")==0))
            {
                data74();
            }
            else if((strcmp(strupr(s),"RHENIUM")==0) || (strcmp(strlwr(s),"rhenium")==0))
            {
                data75();
            }
            else if((strcmp(strupr(s),"OSMIUM")==0) || (strcmp(strlwr(s),"osmium")==0))
            {
                data76();
            }
            else if((strcmp(strupr(s),"IRIDIUM")==0) || (strcmp(strlwr(s),"iridium")==0))
            {
                data77();
            }
            else if((strcmp(strupr(s),"PLATINUM")==0) || (strcmp(strlwr(s),"platinum")==0))
            {
                data78();
            }
            else if((strcmp(strupr(s),"GOLD")==0) || (strcmp(strlwr(s),"gold")==0))
            {
                data79();
            }
            else if((strcmp(strupr(s),"MERCURY")==0) || (strcmp(strlwr(s),"mercury")==0))
            {
                data80();
            }
            else if((strcmp(strupr(s),"THALLIUM")==0) || (strcmp(strlwr(s),"thallium")==0))
            {
                data81();
            }
            else if((strcmp(strupr(s),"LEAD")==0) || (strcmp(strlwr(s),"lead")==0))
            {
                data82();
            }
            else if((strcmp(strupr(s),"BISMUTH")==0) || (strcmp(strlwr(s),"bismuth")==0))
            {
                data83();
            }
            else if((strcmp(strupr(s),"POLONIUM")==0) || (strcmp(strlwr(s),"polonium")==0))
            {
                data84();
            }
            else if((strcmp(strupr(s),"ASTATINE")==0) || (strcmp(strlwr(s),"astatine")==0))
            {
                data85();
            }
            else if((strcmp(strupr(s),"RADON")==0) || (strcmp(strlwr(s),"radon")==0))
            {
                data86();
            }
            else if((strcmp(strupr(s),"FRANCIUM")==0) || (strcmp(strlwr(s),"francium")==0))
            {
                data87();
            }
            else if((strcmp(strupr(s),"RADIUM")==0) || (strcmp(strlwr(s),"radium")==0))
            {
                data88();
            }
            else if((strcmp(strupr(s),"ACTINIUM")==0) || (strcmp(strlwr(s),"actinium")==0))
            {
                data89();
            }
            else if((strcmp(strupr(s),"THORIUM")==0) || (strcmp(strlwr(s),"thorium")==0))
            {
                data90();
            }
            else if((strcmp(strupr(s),"PROTACTINIUM")==0) || (strcmp(strlwr(s),"protactinium")==0))
            {
                data91();
            }
            else if((strcmp(strupr(s),"URANIUM")==0) || (strcmp(strlwr(s),"uranium")==0))
            {
                data92();
            }
            else if((strcmp(strupr(s),"NEPTUNIUM")==0) || (strcmp(strlwr(s),"neptunium")==0))
            {
                data93();
            }
            else if((strcmp(strupr(s),"PLUTONIUM")==0) || (strcmp(strlwr(s),"plutonium")==0))
            {
                data94();
            }
            else if((strcmp(strupr(s),"AMERICIUM")==0) || (strcmp(strlwr(s),"americium")==0))
            {
                data95();
            }
            else if((strcmp(strupr(s),"CURIUM")==0) || (strcmp(strlwr(s),"curium")==0))
            {
                data96();
            }
            else if((strcmp(strupr(s),"BERKELIUM")==0) || (strcmp(strlwr(s),"berkelium")==0))
            {
                data97();
            }
            else if((strcmp(strupr(s),"CALIFORNIUM")==0) || (strcmp(strlwr(s),"californium")==0))
            {
                data98();
            }
            else if((strcmp(strupr(s),"EINSTEINIUM")==0) || (strcmp(strlwr(s),"einsteinium")==0))
            {
                data99();
            }
            else if((strcmp(strupr(s),"FERMIUM")==0) || (strcmp(strlwr(s),"fermium")==0))
            {
                data100();
            }
            else if((strcmp(strupr(s),"MENDELEVIUM")==0) || (strcmp(strlwr(s),"mendelevium")==0))
            {
                data101();
            }
            else if((strcmp(strupr(s),"NOBELIUM")==0) || (strcmp(strlwr(s),"nobelium")==0))
            {
                data102();
            }
            else if((strcmp(strupr(s),"LAWRENCIUM")==0) || (strcmp(strlwr(s),"lawrencium")==0))
            {
                data103();
            }
            else if((strcmp(strupr(s),"RUTHERFORDIUM")==0) || (strcmp(strlwr(s),"rutherfordium")==0))
            {
                data104();
            }
            else if((strcmp(strupr(s),"DUBNIUM")==0) || (strcmp(strlwr(s),"dubnium")==0))
            {
                data105();
            }
            else if((strcmp(strupr(s),"SEABORGIUM")==0) || (strcmp(strlwr(s),"seaborgium")==0))
            {
                data106();
            }
            else if((strcmp(strupr(s),"BOHRIUM")==0) || (strcmp(strlwr(s),"bohrium")==0))
            {
                data107();
            }
            else if((strcmp(strupr(s),"HASSIUM")==0) || (strcmp(strlwr(s),"hassium")==0))
            {
                data108();
            }
            else if((strcmp(strupr(s),"MEITNERIUM")==0) || (strcmp(strlwr(s),"meitnerium")==0))
            {
                data109();
            }
            else if((strcmp(strupr(s),"DARMSTADTIUM")==0) || (strcmp(strlwr(s),"darmstadtium")==0))
            {
                data110();
            }
            else if((strcmp(strupr(s),"ROENTGENIUM")==0) || (strcmp(strlwr(s),"roentgenium")==0))
            {
                data111();
            }
            else if((strcmp(strupr(s),"COPERNICIUM")==0) || (strcmp(strlwr(s),"copernicium")==0))
            {
                data112();
            }
            else if((strcmp(strupr(s),"NIHONIUM")==0) || (strcmp(strlwr(s),"nihonium")==0))
            {
                data113();
            }
            else if((strcmp(strupr(s),"FLEROVIUM")==0) || (strcmp(strlwr(s),"flerovium")==0))
            {
                data114();
            }
            else if((strcmp(strupr(s),"MOSCOVIUM")==0) || (strcmp(strlwr(s),"moscovium")==0))
            {
                data115();
            }
            else if((strcmp(strupr(s),"LIVERMORIUM")==0) || (strcmp(strlwr(s),"livermorium")==0))
            {
                data116();
            }
            else if((strcmp(strupr(s),"TENNESSINE")==0) || (strcmp(strlwr(s),"tennessine")==0))
            {
                data117();
            }
            else if((strcmp(strupr(s),"OGANESSON")==0) || (strcmp(strlwr(s),"oganesson")==0))
            {
                data118();
            }
            else
            {
                printf("\t :: ERROR! :: \n\t Incorrect Spelling \n\t or \n\t There is No Element Exists Named as '%s'. Search Again.... \n\n", s);
            }

            break;

        default:
            printf("\n\tYour Choice '%d' Isn't a Valid Search. \n\tEnter Your Choice between 1 to 3. \n\n", choice);
            break;

    }

    loop2:
    printf("\n\n\n");

    char ch;
    printf("\tDo You Want to Search Again?\n\tType 'Y/y' for 'Yes' or Type 'N/n' for 'No' \n\tEnter Your Choice: ");
    scanf("%s", &ch);
    system("COLOR FC");
    printf("\n\n");
    switch(ch)
    {
        case 'y':
        case 'Y':
            goto loop1;
            break;

        case 'n':
        case 'N':
            exit(0);
            break;
        default:
            printf("\n\tInvalid Input!!!\n\tYour Choice '%c' isn't Correct.\n\n", ch);
            goto loop2;
            break;
    }

    system("pause");

    return 0;
}

void data1()
{
    FILE * fp;
    char x[50];
    fp = fopen("001. Hydrogen.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data2()
{
    FILE * fp;
    char x[50];
    fp = fopen("002. Helium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data3()
{
    FILE * fp;
    char x[50];
    fp = fopen("003. Lithium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data4()
{
    FILE * fp;
    char x[50];
    fp = fopen("004. Beryllium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data5()
{
    FILE * fp;
    char x[50];
    fp = fopen("005. Boron.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data6()
{
    FILE * fp;
    char x[50];
    fp = fopen("006. Carbon.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data7()
{
    FILE * fp;
    char x[50];
    fp = fopen("007. Nitrogen.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data8()
{
    FILE * fp;
    char x[50];
    fp = fopen("008. Oxygen.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data9()
{
    FILE * fp;
    char x[50];
    fp = fopen("009. Fluorine.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data10()
{
    FILE * fp;
    char x[50];
    fp = fopen("010. Neon.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data11()
{
    FILE * fp;
    char x[50];
    fp = fopen("011. Sodium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data12()
{
    FILE * fp;
    char x[50];
    fp = fopen("012. Magnesium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data13()
{
    FILE * fp;
    char x[50];
    fp = fopen("013. Aluminium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data14()
{
    FILE * fp;
    char x[50];
    fp = fopen("014. Silicon.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data15()
{
    FILE * fp;
    char x[50];
    fp = fopen("015. Phosphorus.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data16()
{
    FILE * fp;
    char x[50];
    fp = fopen("016. Sulfur.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data17()
{
    FILE * fp;
    char x[50];
    fp = fopen("017. Chlorine.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data18()
{
    FILE * fp;
    char x[50];
    fp = fopen("018. Argon.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data19()
{
    FILE * fp;
    char x[50];
    fp = fopen("019. Potassium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data20()
{
    FILE * fp;
    char x[50];
    fp = fopen("020. Calcium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data21()
{
    FILE * fp;
    char x[50];
    fp = fopen("021. Scandium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data22()
{
    FILE * fp;
    char x[50];
    fp = fopen("022. Titanium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data23()
{
    FILE * fp;
    char x[50];
    fp = fopen("023. Vanadium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data24()
{
    FILE * fp;
    char x[50];
    fp = fopen("024. Chromium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data25()
{
    FILE * fp;
    char x[50];
    fp = fopen("025. Manganese.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data26()
{
    FILE * fp;
    char x[50];
    fp = fopen("026. Iron.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data27()
{
    FILE * fp;
    char x[50];
    fp = fopen("027. Cobalt.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data28()
{
    FILE * fp;
    char x[50];
    fp = fopen("028. Nickel.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data29()
{
    FILE * fp;
    char x[50];
    fp = fopen("029. Copper.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data30()
{
    FILE * fp;
    char x[50];
    fp = fopen("030. Zinc.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data31()
{
    FILE * fp;
    char x[50];
    fp = fopen("031. Gallium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data32()
{
    FILE * fp;
    char x[50];
    fp = fopen("032. Germanium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data33()
{
    FILE * fp;
    char x[50];
    fp = fopen("033. Arsenic.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data34()
{
    FILE * fp;
    char x[50];
    fp = fopen("034. Selenium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data35()
{
    FILE * fp;
    char x[50];
    fp = fopen("035. Bromine.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data36()
{
    FILE * fp;
    char x[50];
    fp = fopen("036. Krypton.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data37()
{
    FILE * fp;
    char x[50];
    fp = fopen("037. Rubidium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data38()
{
    FILE * fp;
    char x[50];
    fp = fopen("038. Strontium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data39()
{
    FILE * fp;
    char x[50];
    fp = fopen("039. Yttrium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data40()
{
    FILE * fp;
    char x[50];
    fp = fopen("040. Zirconium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data41()
{
    FILE * fp;
    char x[50];
    fp = fopen("041. Niobium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data42()
{
    FILE * fp;
    char x[50];
    fp = fopen("042. Molybdenum.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data43()
{
    FILE * fp;
    char x[50];
    fp = fopen("043. Technetium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data44()
{
    FILE * fp;
    char x[50];
    fp = fopen("044. Ruthenium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data45()
{
    FILE * fp;
    char x[50];
    fp = fopen("045. Rhodium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data46()
{
    FILE * fp;
    char x[50];
    fp = fopen("046. Palladium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data47()
{
    FILE * fp;
    char x[50];
    fp = fopen("047. Silver.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data48()
{
    FILE * fp;
    char x[50];
    fp = fopen("048. Cadmium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data49()
{
    FILE * fp;
    char x[50];
    fp = fopen("049. Indium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data50()
{
    FILE * fp;
    char x[50];
    fp = fopen("050. Tin.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data51()
{
    FILE * fp;
    char x[50];
    fp = fopen("051. Antimony.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data52()
{
    FILE * fp;
    char x[50];
    fp = fopen("052. Tellurium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data53()
{
    FILE * fp;
    char x[50];
    fp = fopen("053. Iodine.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data54()
{
    FILE * fp;
    char x[50];
    fp = fopen("054. Xenon.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data55()
{
    FILE * fp;
    char x[50];
    fp = fopen("055. Caesium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data56()
{
    FILE * fp;
    char x[50];
    fp = fopen("056. Barium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data57()
{
    FILE * fp;
    char x[50];
    fp = fopen("057. Lanthanum.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data58()
{
    FILE * fp;
    char x[50];
    fp = fopen("058. Cerium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data59()
{
    FILE * fp;
    char x[50];
    fp = fopen("059. Praseodymium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data60()
{
    FILE * fp;
    char x[50];
    fp = fopen("060. Neodymium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data61()
{
    FILE * fp;
    char x[50];
    fp = fopen("061. Promethium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data62()
{
    FILE * fp;
    char x[50];
    fp = fopen("062. Samarium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data63()
{
    FILE * fp;
    char x[50];
    fp = fopen("063. Europium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data64()
{
    FILE * fp;
    char x[50];
    fp = fopen("064. Gadolinium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data65()
{
    FILE * fp;
    char x[50];
    fp = fopen("065. Terbium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data66()
{
    FILE * fp;
    char x[50];
    fp = fopen("066. Dysprosium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data67()
{
    FILE * fp;
    char x[50];
    fp = fopen("067. Holmium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data68()
{
    FILE * fp;
    char x[50];
    fp = fopen("068. Erbium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data69()
{
    FILE * fp;
    char x[50];
    fp = fopen("069. Thulium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data70()
{
    FILE * fp;
    char x[50];
    fp = fopen("070. Ytterbium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data71()
{
    FILE * fp;
    char x[50];
    fp = fopen("071. Lutetium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data72()
{
    FILE * fp;
    char x[50];
    fp = fopen("072. Hafnium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data73()
{
    FILE * fp;
    char x[50];
    fp = fopen("073. Tantalum.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data74()
{
    FILE * fp;
    char x[50];
    fp = fopen("074. Tungsten.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data75()
{
    FILE * fp;
    char x[50];
    fp = fopen("075. Rhenium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data76()
{
    FILE * fp;
    char x[50];
    fp = fopen("076. Osmium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data77()
{
    FILE * fp;
    char x[50];
    fp = fopen("077. Iridium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data78()
{
    FILE * fp;
    char x[50];
    fp = fopen("078. Platium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data79()
{
    FILE * fp;
    char x[50];
    fp = fopen("079. Gold.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data80()
{
    FILE * fp;
    char x[50];
    fp = fopen("080. Mercury.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data81()
{
    FILE * fp;
    char x[100];
    fp = fopen("081. Thallium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data82()
{
    FILE * fp;
    char x[100];
    fp = fopen("082. Lead.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data83()
{
    FILE * fp;
    char x[100];
    fp = fopen("083. Bismuth.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data84()
{
    FILE * fp;
    char x[100];
    fp = fopen("084. Polonium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data85()
{
    FILE * fp;
    char x[100];
    fp = fopen("085. Astatine.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data86()
{
    FILE * fp;
    char x[100];
    fp = fopen("086. Radon.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data87()
{
    FILE * fp;
    char x[50];
    fp = fopen("087. Francium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data88()
{
    FILE * fp;
    char x[50];
    fp = fopen("088. Radium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data89()
{
    FILE * fp;
    char x[50];
    fp = fopen("089. Actinium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data90()
{
    FILE * fp;
    char x[50];
    fp = fopen("090. Thorium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data91()
{
    FILE * fp;
    char x[50];
    fp = fopen("091. Protactinium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data92()
{
    FILE * fp;
    char x[50];
    fp = fopen("092. Uranium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data93()
{
    FILE * fp;
    char x[50];
    fp = fopen("093. Neptunium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data94()
{
    FILE * fp;
    char x[50];
    fp = fopen("094. Plutonium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data95()
{
    FILE * fp;
    char x[50];
    fp = fopen("095. Americium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data96()
{
    FILE * fp;
    char x[50];
    fp = fopen("096. Curium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data97()
{
    FILE * fp;
    char x[50];
    fp = fopen("097. Berkelium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data98()
{
    FILE * fp;
    char x[50];
    fp = fopen("098. Californium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data99()
{
    FILE * fp;
    char x[50];
    fp = fopen("099. Einsteinium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data100()
{
    FILE * fp;
    char x[50];
    fp = fopen("100. Fermium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data101()
{
    FILE * fp;
    char x[50];
    fp = fopen("101. Mendelevium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data102()
{
    FILE * fp;
    char x[50];
    fp = fopen("102. Nobelium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data103()
{
    FILE * fp;
    char x[50];
    fp = fopen("103. Lawrencium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data104()
{
    FILE * fp;
    char x[50];
    fp = fopen("104. Rutherfordium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data105()
{
    FILE * fp;
    char x[50];
    fp = fopen("105. Dubnium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data106()
{
    FILE * fp;
    char x[50];
    fp = fopen("106. Seaborgium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data107()
{
    FILE * fp;
    char x[50];
    fp = fopen("107. Bohrium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data108()
{
    FILE * fp;
    char x[50];
    fp = fopen("108. Hassium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data109()
{
    FILE * fp;
    char x[50];
    fp = fopen("109. Meitnerium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 50, fp);
        puts(x);
    }
    fclose(fp);
}

void data110()
{
    FILE * fp;
    char x[100];
    fp = fopen("110. Darmstadtium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data111()
{
    FILE * fp;
    char x[100];
    fp = fopen("111. Roentgenium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data112()
{
    FILE * fp;
    char x[100];
    fp = fopen("112. Copernicium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data113()
{
    FILE * fp;
    char x[100];
    fp = fopen("113. Nihonium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data114()
{
    FILE * fp;
    char x[100];
    fp = fopen("114. Flerovium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data115()
{
    FILE * fp;
    char x[100];
    fp = fopen("115. Moscovium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data116()
{
    FILE * fp;
    char x[100];
    fp = fopen("116. Livermorium.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data117()
{
    FILE * fp;
    char x[100];
    fp = fopen("117. Tennessine.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}

void data118()
{
    FILE * fp;
    char x[100];
    fp = fopen("118. Oganesson.txt", "r");

    while(!feof(fp))
    {
        fgets(x, 100, fp);
        puts(x);
    }
    fclose(fp);
}
